import React from 'react'

function Deals() {
  return (
    <div className='d-flex flex-column  align-items-center' >
      <p className='deals-text'>GOS</p>
      <p className='deals-flash'>Flash</p>
      <p className='deals'>Deals</p>
    </div>
  )
}

export default Deals
